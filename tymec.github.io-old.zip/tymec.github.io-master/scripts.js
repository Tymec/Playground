function gameRedirect(){
    window.location.href = "https://tymec.itch.io/data";
}